package br.com.varejo.dal;
import java.sql.*;

public class ModuloConexao {
    @SuppressWarnings("UseSpecificCatch")
    public static Connection conector(){ // Criando método com nome de: conector

        @SuppressWarnings("UnusedAssignment")
        java.sql.Connection conexao = null; //variável com nome de: conexao

String driver = "com.mysql.cj.jdbc.Driver"; //chamando o driver
String url= "jdbc:mysql://localhost:3306/dbvarejo"; //Armazenando informações referente ao banco
String user="root";
String password ="Ingryd1970";

try {
Class.forName(driver); //tratamento de conexão ao banco de dados
conexao = DriverManager.getConnection(url, user, password);
return conexao;
} catch (Exception e) {
return null;
}
}
}

