
package br.com.varejo.telas;

import java.sql.*;
import br.com.varejo.dal.ModuloConexao;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;

public class TelaEstoque extends javax.swing.JFrame {

   Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null; //exibe o resultado da conexão
    
    public TelaEstoque() {
        initComponents();
        setExtendedState(MAXIMIZED_BOTH);
        conexao = ModuloConexao.conector(); //CHAMANDO O MÉTODO CONECTOR
    }
//   tratativa para conferir se são somente números
    private static boolean isInteger(String str) {
        return str != null && str.matches("[0-9]*\\.?[0-9]+");}
    
    //Método usado como tratativa para verificar se o produto existe
    private void verificaIdProduto() { 
    String sql = "select * from tbprodutos where idproduto=?";
       
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtIdProduto.getText());
            rs = pst.executeQuery();
            
            if (rs.next()) {
                
                adicionarEstoque(); //se o produto existir, autoriza adicionar estoque
                
                
            } else {
               JOptionPane.showMessageDialog(null, "Produto não cadastrado");
    
    }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);}
    }
    
    private void adicionarEstoque() {            
        String sql = "select * from tbestoque where idestoque=?";
        
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtIdProduto.getText());
            rs = pst.executeQuery();
            
            if (rs.next()) {
                
                JOptionPane.showMessageDialog(null, "Estoque já existente, use Editar!");
                txtIdProduto.setText(null);
                txtEstoqueAtual.setText(null);
                
                
            } else {
                String sql1 = "insert into tbestoque( idestoque,quantidade) values(?,?)";
       //if (isInteger(txtVenda.getText()) && isInteger(txtCusto.getText())){
        try {
            pst = conexao.prepareStatement(sql1);
            //pst.setString(1, txtId.getText());
           
            pst.setString(1, txtIdProduto.getText());
            pst.setString(2, txtEstoqueAtual.getText());
            
            int adicionado = pst.executeUpdate();
            if (adicionado > 0) {
                JOptionPane.showMessageDialog(null, "Estoque cadastrado com sucesso");
               
               txtIdProduto.setText(null);
               txtEstoqueAtual.setText(null);
          
        
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
       
   // }else{JOptionPane.showMessageDialog(null, "Valores de custo e venda somente números!");}// linha da tratativa
                //txtCusto.setText(rs.getString(7));
                //txtVenda.setText(rs.getString(8));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Produto não encontrado.");
        }
   
    }
    
    private void removerEstoque() {
        int confirma = JOptionPane.
        showConfirmDialog(null, "Tem certeza que deseja remover este estoque ? ",
                        "  Atenção", JOptionPane.YES_NO_OPTION);
if (confirma == JOptionPane.YES_OPTION) {
            String sql = "delete from tbestoque where idestoque=?";
            try {
                pst = conexao.prepareStatement(sql);
                pst.setString(1, txtIdProduto.getText());
                int apagado = pst.executeUpdate();
                if (apagado > 0) {
                    JOptionPane.showMessageDialog(null, "Produto removido com sucesso");
                    
                    txtIdProduto.setText(null);
                    txtEstoqueAtual.setText(null);
                    
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Estoque ou produto não escontrados");
            }
        }
    }
    
    
    private void mostrarProdutoTabela(){
               String  sql= "select * from tbprodutos where categoria like ?";
               
               try {
                pst = conexao.prepareStatement(sql);
                
                pst.setString(1, jComboBox1_Categoria.getSelectedItem().toString()+ "%");
                
                rs=pst.executeQuery();
                
                tblCategoria.setModel(DbUtils.resultSetToTableModel(rs));
                
                                         
            } catch (Exception e) {
                
                JOptionPane.showMessageDialog(null, e);
            }  
        }
     private void verificaIdEstoque() { 
    String sql = "select * from tbestoque where idestoque=?";
       
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtIdProduto.getText());
            rs = pst.executeQuery();
            
            if (rs.next()) {
                
                alteraEstoque(); //se o estoque existir, autoriza alterar estoque
                
                
            } else {
               JOptionPane.showMessageDialog(null, "Estoque não cadastrado");
    
    }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);}
    }
     private void alteraEstoque() { //com tratativa para conferir se são somente números
        String sql = "update tbestoque set quantidade=?";
        
        
        if (isInteger(txtIdProduto.getText()) && isInteger(txtEstoqueAtual.getText())){// linha da tratativa
        try {
            
            pst = conexao.prepareStatement(sql);
            pst.setString(1,txtEstoqueAtual.getText());
            
            int adicionado = pst.executeUpdate();
            if (adicionado > 0) {
                JOptionPane.showMessageDialog(null, "Produto alterado com sucesso");
                
                txtIdProduto.setText(null);
                txtEstoqueAtual.setText(null);
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Estoque ou produto não existentes");
        }
        }else{JOptionPane.showMessageDialog(null, "ID e Estoque somente números!");}// linha da tratativa
    }
    private void pesquisarProdutosCompleto(){

 String num_ID =JOptionPane.showInputDialog("Número da ID do produto");
 String sql = "select * from tbestoque where idestoque =?";

 try{
 pst=conexao.prepareStatement(sql);
 pst.setString(1, num_ID);
 rs=pst.executeQuery();

  if (rs.next()) {
                txtIdProduto.setText(rs.getString(1));
                txtEstoqueAtual.setText(rs.getString(2));
                

                //EVITANDO PROBLEMAS
                btnAdicionar.setEnabled(false);
                jComboBox1_Categoria.setEnabled(false);
                tblCategoria.setVisible(false);

            } else {
                JOptionPane.showMessageDialog(null, "Estoque não cadastrado");
                txtEstoqueAtual.setText(null);
                txtIdProduto.setText(null);
                

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);

        }
    }
    
    private void limpaCampos(){

    txtEstoqueAtual.setText(null);
    txtIdProduto.setText(null);
    
    DefaultTableModel model = new DefaultTableModel();// Servem para zerar tabela
    tblCategoria.setModel(model);
    
    btnAdicionar.setEnabled(true);
    jComboBox1_Categoria.setEnabled(true);
    tblCategoria.setVisible(true);



}
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBox1_Categoria = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCategoria = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txtIdProduto = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtEstoqueAtual = new javax.swing.JTextField();
        btnAdicionar = new javax.swing.JButton();
        btnEditar = new javax.swing.JButton();
        btnPesquisar = new javax.swing.JButton();
        btnRemover = new javax.swing.JButton();
        btnLimpar = new javax.swing.JButton();
        btnBuscarCategoria = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Estoque de Mercadorias");
        setBackground(new java.awt.Color(255, 204, 204));
        setPreferredSize(new java.awt.Dimension(1150, 630));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 250, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 840, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 250, 840));

        jPanel2.setBackground(new java.awt.Color(255, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Categoria");

        jComboBox1_Categoria.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Roupa", "Calçado", "Acessório" }));
        jComboBox1_Categoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox1_CategoriaActionPerformed(evt);
            }
        });

        tblCategoria.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Categoria", "Descrição", "Tamanho"
            }
        ));
        jScrollPane1.setViewportView(tblCategoria);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Código do Produto");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Estoque Atual");

        txtEstoqueAtual.setText("0");
        txtEstoqueAtual.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEstoqueAtualActionPerformed(evt);
            }
        });

        btnAdicionar.setText("Adicionar");
        btnAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarActionPerformed(evt);
            }
        });

        btnEditar.setText("Editar");
        btnEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditarActionPerformed(evt);
            }
        });

        btnPesquisar.setText("Pesquisar");
        btnPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPesquisarActionPerformed(evt);
            }
        });

        btnRemover.setText("Remover");
        btnRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRemoverActionPerformed(evt);
            }
        });

        btnLimpar.setText("Limpar");
        btnLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLimparActionPerformed(evt);
            }
        });

        btnBuscarCategoria.setText("Buscar");
        btnBuscarCategoria.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarCategoriaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnAdicionar, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(btnEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(btnPesquisar, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(btnRemover, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(51, 51, 51)
                .addComponent(btnLimpar, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(136, 136, 136))
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(28, 28, 28)
                        .addComponent(jComboBox1_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(34, 34, 34)
                        .addComponent(btnBuscarCategoria))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(txtIdProduto, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(53, 53, 53)
                        .addComponent(txtEstoqueAtual, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 877, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jComboBox1_Categoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnBuscarCategoria)))
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(txtIdProduto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(txtEstoqueAtual, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 82, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAdicionar)
                    .addComponent(btnEditar)
                    .addComponent(btnPesquisar)
                    .addComponent(btnRemover)
                    .addComponent(btnLimpar))
                .addGap(77, 77, 77))
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 120, -1, -1));

        jPanel3.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1130, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 120, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 0, 1130, 120));

        jPanel4.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 210, Short.MAX_VALUE)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 750, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(1170, 120, 210, 750));

        jPanel5.setBackground(new java.awt.Color(255, 204, 204));

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 920, Short.MAX_VALUE)
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 260, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 580, 920, 260));

        setSize(new java.awt.Dimension(1400, 907));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtEstoqueAtualActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEstoqueAtualActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEstoqueAtualActionPerformed

    private void jComboBox1_CategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1_CategoriaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1_CategoriaActionPerformed

    private void btnAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarActionPerformed
verificaIdProduto();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnAdicionarActionPerformed

    private void btnBuscarCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarCategoriaActionPerformed
mostrarProdutoTabela();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscarCategoriaActionPerformed

    private void btnPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPesquisarActionPerformed
pesquisarProdutosCompleto();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnPesquisarActionPerformed

    private void btnLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLimparActionPerformed
limpaCampos();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnLimparActionPerformed

    private void btnEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditarActionPerformed
verificaIdEstoque();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditarActionPerformed

    private void btnRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRemoverActionPerformed
removerEstoque();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnRemoverActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaEstoque.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaEstoque().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionar;
    private javax.swing.JButton btnBuscarCategoria;
    private javax.swing.JButton btnEditar;
    private javax.swing.JButton btnLimpar;
    private javax.swing.JButton btnPesquisar;
    private javax.swing.JButton btnRemover;
    private javax.swing.JComboBox<String> jComboBox1_Categoria;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCategoria;
    private javax.swing.JTextField txtEstoqueAtual;
    private javax.swing.JTextField txtIdProduto;
    // End of variables declaration//GEN-END:variables
}
