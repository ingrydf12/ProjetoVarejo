//Ideia da tela (Inicial)
// Lucro é automatico ou funcionar quando clicar no botão de adicionar venda (Valor Custo - Valor Venda = Lucro) 
//*obs: funciona se apertar enter
// Estoque atual deve ser automático pelo sistema e deve funcionar junto ao tela produto ou tela de estoque (se existir)
// Quando uma venda for adicionada, o estoque do produto deve alterar (Ideia)

package br.com.varejo.telas;

import java.sql.*;
import br.com.varejo.dal.ModuloConexao;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showConfirmDialog;
import javax.swing.table.DefaultTableModel;
import net.proteanit.sql.DbUtils;



public class TelaVendas extends javax.swing.JFrame {
//UTILIZANDO FRAMEWORKS DO PACOTE MODULO DE CONEXÃO

    Connection conexao = null;
    PreparedStatement pst = null;
    ResultSet rs = null; //exibe o resultado da conexão
    
    public TelaVendas() {
        initComponents();
        setExtendedState(MAXIMIZED_BOTH);
        
        conexao = ModuloConexao.conector(); //CHAMANDO O MÉTODO CONECTOR
    }

    // Apenas números
    private static boolean isInteger(String str) {
        return str != null && str.matches("[0-9]*\\.?[0-9]+");}
    
    
    
    
    // Método de adicionarVenda (Funcionando)
    private void adicionarProduto(){
        String sql = "insert into tbvendas (idvenda,idcliente,nomecliente,"
              +"iditem,vendedor,valor_custo, valor_venda, quantidade) values(?,?,?,?,?,?,?,?)";
       if (isInteger(txtQuantidade.getText()) && isInteger(txtIdProduto.getText())){
        try {
            
            int total,quantidade,valor;
            quantidade = Integer.parseInt(txtQuantidade.getText());
            valor = Integer.parseInt(txtVenda.getText());
            total = quantidade * valor;
            txtValorTotal.setText(Integer.toString(total));
            
            
            pst = conexao.prepareStatement(sql);
           
            pst.setString(1,null);
            pst.setString(2, txtIdCli.getText());
            pst.setString(3,txtNomeCli.getText());
            pst.setString(4, txtIdProduto.getText());
            pst.setString(5, txtVendedor.getText());
            pst.setString(6, txtVenda.getText());
            pst.setString(7, txtValorTotal.getText());
            pst.setString(8, txtQuantidade.getText());
            int adicionado = pst.executeUpdate();
            
            if (adicionado > 0) {
                JOptionPane.showMessageDialog(null, "Venda cadastrada com sucesso");
               
                txtIdProduto.setText(null);
              
                txtQuantidade.setText(null);
                txtValorTotal.setText(null);
                txtVenda.setText(null);
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
       
    }else{JOptionPane.showMessageDialog(null, "Valores de quantidade e ID somente números (Obrigatório)");}// linha da tratativa
    }
    
    private void adicionarVenda(){
        String sql = "insert into tbvendas (idvenda,idcliente,nomecliente,"
              +"iditem,vendedor,valor_custo, valor_venda, quantidade) values(?,?,?,?,?,?,?,?)";
       if (isInteger(txtQuantidade.getText()) && isInteger(txtIdProduto.getText())){
        try {
            
            int total,quantidade,valor;
            quantidade = Integer.parseInt(txtQuantidade.getText());
            valor = Integer.parseInt(txtVenda.getText());
            total = quantidade * valor;
            txtValorTotal.setText(Integer.toString(total));
            
            
            pst = conexao.prepareStatement(sql);
           
            pst.setString(1,null);
            pst.setString(2, txtIdCli.getText());
            pst.setString(3,txtNomeCli.getText());
            pst.setString(4, txtIdProduto.getText());
            pst.setString(5, txtVendedor.getText());
            pst.setString(6, txtVenda.getText());
            pst.setString(7, txtValorTotal.getText());
            pst.setString(8, txtQuantidade.getText());
            int adicionado = pst.executeUpdate();
            
            if (adicionado > 0) {
                JOptionPane.showMessageDialog(null, "Venda cadastrada com sucesso");
               
                txtIdProduto.setText(null);
              
                txtQuantidade.setText(null);
                txtValorTotal.setText(null);
                txtVenda.setText(null);
                txtCpfCli.setText(null);
                txtIdCli.setText(null);
                txtNomeCli.setText(null);
                txtVendedor.setText(null);
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
       
    }else{JOptionPane.showMessageDialog(null, "Valores de quantidade e "
            + "ID somente números (Obrigatório)");}// linha da tratativa
    }
    
    
    
       // Método de pesquisa de vendas (Funcionando - Apenas ID)
    private void pesquisarVenda() {
        String sql = "select * from tbvendas where nomecliente like ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtVendaPesquisar.getText() + "%");
            rs = pst.executeQuery();
            tabVendas.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
    }
    
     private void pesquisarProduto() {
        String sql = "select * from tbprodutos where descricao like ?";
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtProdutoPesquisar.getText() + "%");
            rs = pst.executeQuery();
            tblProduto.setModel(DbUtils.resultSetToTableModel(rs));

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, e);
        }
    }
    
    
    //Método de alterarVenda (Verificar)
    private void alterarVenda() {
        String num_ID = JOptionPane.showInputDialog("Confirme da ID da venda");
        int confirma = JOptionPane.
                showConfirmDialog(null, "Tem certeza que deseja editar a venda com esses dados?",
                        "Atenção", JOptionPane.YES_NO_OPTION);

        if (confirma == JOptionPane.YES_OPTION) {
            String sql = "update tbvendas set idvenda =? idcliente=?, nomecliente=?, iditem=?, vendedor=?"
                    + "valor_custo=?, valor_venda =?,quantidade =?" + "where idvenda=?";

            try {
                pst = conexao.prepareStatement(sql);
                pst.setString(1, num_ID);
                rs = pst.executeQuery();

                if (rs.next()) {
                    try {
                        pst = conexao.prepareStatement(sql);
                        pst.setString(1, null);
                        pst.setString(2, txtIdCli.getText());
                        pst.setString(3, txtNomeCli.getText());
                        pst.setString(4, txtIdProduto.getText());
                        pst.setString(5, txtVendedor.getText());
                        pst.setString(6, txtVenda.getText());
                        pst.setString(7, txtValorTotal.getText());
                        pst.setString(8, txtQuantidade.getText());
                        int adicionado = pst.executeUpdate();
                        if (adicionado > 0) {
                            JOptionPane.showMessageDialog(null, "Venda alterada com sucesso");

                            txtIdProduto.setText(null);
                            txtQuantidade.setText(null);
                            txtValorTotal.setText(null);
                            txtVenda.setText(null);
                            txtCpfCli.setText(null);
                            txtIdCli.setText(null);
                            txtNomeCli.setText(null);
                            txtVendedor.setText(null);
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Venda não cadastrada");

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Campo inválido");

            }
        } else {
            JOptionPane.showMessageDialog(null, "Venda não alterada");
        }

    }

    
    // Método removerVenda (Verificar)
    // Mudar o get.Text para o txtVendaPesquisar ou no próprio painel (ID de VENDA)
    // String num_ID =JOptionPane.showInputDialog("Número da ID da Venda);
    private void removerVenda() {
        String num_ID = JOptionPane.showInputDialog("Confirme da ID da venda");
        int confirma = JOptionPane.
                showConfirmDialog(null, "Tem certeza que deseja excluir a venda?",
                        "Atenção", JOptionPane.YES_NO_OPTION);
        if (confirma == JOptionPane.YES_OPTION) {
            // String num_ID =JOptionPane.showInputDialog("Número da ID da Venda);
            try {
                String sql = "select * from tbprodutos where idproduto=?";
                pst = conexao.prepareStatement(sql);
                pst.setString(1, num_ID);
                rs = pst.executeQuery();

                if (rs.next()) {
                    String sql1 = "delete from tbvendas where idvenda = ?";
                    try {
                        pst = conexao.prepareStatement(sql1);
                        pst.setString(1, num_ID);
                        int apagado = pst.executeUpdate();
                        if (apagado > 0) {
                            JOptionPane.showMessageDialog(null, "Venda deletada com sucesso");

                            txtIdProduto.setText(null);
                            txtQuantidade.setText(null);
                            txtValorTotal.setText(null);
                            txtVenda.setText(null);
                            txtCpfCli.setText(null);
                            txtIdCli.setText(null);
                            txtNomeCli.setText(null);
                            txtVendedor.setText(null);
                           // btnVendaAdicionar.setEnabled(true);
                            //txtVendaPesquisar.setEnabled(true);
                            //tabVendas.setVisible(true);
                        } else {
                            JOptionPane.showMessageDialog(null, "Venda não deletada");
                        }
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Venda não encontrada");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Campo inválido");
            }

        } else {
            JOptionPane.showMessageDialog(null, "Venda não deletada");
        }
    }

    
    
    // Método do botão pesquisar (Completo) [VERIFICAR]
    private void pesquisarCompleto() {

        String num_ID = JOptionPane.showInputDialog("Número da ID da Venda");
        String sql = "select * from tbvendas where idvenda =?";

        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, num_ID);
            rs = pst.executeQuery();

            if (rs.next()) {
                txtIdCli.setText(rs.getString(2));
                txtNomeCli.setText(rs.getString(3));
                txtIdProduto.setText(rs.getString(4));
                txtVendedor.setText(rs.getString(5));
                txtVenda.setText(rs.getString(6));
                txtValorTotal.setText(rs.getString(7));
                txtQuantidade.setText(rs.getString(8));

                //EVITANDO PROBLEMAS
                btnVendaAdicionar.setEnabled(false);
                txtVendaPesquisar.setEnabled(false);
                tabVendas.setVisible(false);

            } else {
                JOptionPane.showMessageDialog(null, "Venda não cadastrada");
                txtIdProduto.setText(null);
                txtQuantidade.setText(null);
                txtValorTotal.setText(null);
                txtVenda.setText(null);
                txtCpfCli.setText(null);
                txtIdCli.setText(null);
                txtNomeCli.setText(null);
                txtVendedor.setText(null);
                txtVendaPesquisar.setText(null);

            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Venda não encontrada");

        }
    }

   
    
    // Método de limpar os campos
    private void limpar(){
                txtNomeCli.setText(null);
                txtCpfCli.setText(null);
                DefaultTableModel model = new DefaultTableModel();// Servem para zerar tabela
                tblProduto.setModel(model);
                txtVendedor.setText(null);
                txtVenda.setText(null);
                txtValorTotal.setText(null);
                txtIdCli.setText(null);
                txtQuantidade.setText(null);
                txtVendaPesquisar.setText(null);
    }
    private void pesquisarCpfCliente(){

        String sql = "select * from tbclientes where cpf=?";
        if (isInteger(txtCpfCli.getText())){// linha da tratativa
        try {
            pst = conexao.prepareStatement(sql);
            pst.setString(1, txtCpfCli.getText());
            rs = pst.executeQuery();
            if (rs.next()) {
                txtIdCli.setText(rs.getString(1));
                txtNomeCli.setText(rs.getString(2));
                
                
            } else {
                JOptionPane.showMessageDialog(null, "Cliente não cadastrado");
                txtCpfCli.setText(null);
                txtIdCli.setText(null);
                
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
   }else{JOptionPane.showMessageDialog(null, "Valores de CPF somente números!");}// linha da tratativa
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtVenda = new javax.swing.JTextField();
        txtVendedor = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtValorTotal = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtCpfCli = new javax.swing.JTextField();
        btnBuscaCpf = new javax.swing.JButton();
        txtNomeCli = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtIdCli = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtIdProduto = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtQuantidade = new javax.swing.JTextField();
        btnAdicionarProdutoNaVenda = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProduto = new javax.swing.JTable();
        jLabel16 = new javax.swing.JLabel();
        txtProdutoPesquisar = new javax.swing.JTextField();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txtVendaPesquisar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabVendas = new javax.swing.JTable();
        btnVendaAdicionar = new javax.swing.JButton();
        btnVendaPesquisar = new javax.swing.JButton();
        btnVendaEditar = new javax.swing.JButton();
        btnVendaRemover = new javax.swing.JButton();
        btnVendaLimpar = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Vendas", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12))); // NOI18N
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel4.setText("Valor de venda");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 131, -1, -1));
        jPanel2.add(txtVenda, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 132, 104, -1));
        jPanel2.add(txtVendedor, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 90, 250, -1));

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel5.setText("Vendedor");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 90, -1, -1));

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel6.setText("Valor Total");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(342, 131, -1, -1));
        jPanel2.add(txtValorTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 132, 98, -1));

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel1.setText("CPF do Cliente");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 18, -1, -1));
        jPanel2.add(txtCpfCli, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 19, 164, -1));

        btnBuscaCpf.setText("Buscar");
        btnBuscaCpf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscaCpfActionPerformed(evt);
            }
        });
        jPanel2.add(btnBuscaCpf, new org.netbeans.lib.awtextra.AbsoluteConstraints(402, 17, -1, 24));
        jPanel2.add(txtNomeCli, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 52, 750, -1));

        jLabel11.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel11.setText("Nome do cliente");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(49, 51, -1, -1));

        jLabel12.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel12.setText("ID Cliente");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 20, -1, -1));

        txtIdCli.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdCliActionPerformed(evt);
            }
        });
        jPanel2.add(txtIdCli, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 20, 160, -1));

        jLabel13.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel13.setText("Quantidade");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(342, 90, -1, -1));

        txtIdProduto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdProdutoActionPerformed(evt);
            }
        });
        jPanel2.add(txtIdProduto, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 90, 110, -1));

        jLabel15.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        jLabel15.setText("ID Produto");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 90, -1, -1));

        txtQuantidade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtQuantidadeActionPerformed(evt);
            }
        });
        jPanel2.add(txtQuantidade, new org.netbeans.lib.awtextra.AbsoluteConstraints(449, 91, 98, -1));

        btnAdicionarProdutoNaVenda.setText("Adicionar Produto ");
        btnAdicionarProdutoNaVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAdicionarProdutoNaVendaActionPerformed(evt);
            }
        });
        jPanel2.add(btnAdicionarProdutoNaVenda, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 130, 174, -1));

        tblProduto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblProduto);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 212, 965, 103));

        jLabel16.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel16.setText("Buscar Categoria");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 187, -1, -1));

        txtProdutoPesquisar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtProdutoPesquisarKeyReleased(evt);
            }
        });
        jPanel2.add(txtProdutoPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(151, 186, 830, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 50, 1005, 340));

        jPanel3.setBackground(new java.awt.Color(255, 204, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder("")));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel10.setText("Buscar Venda");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 32, -1, -1));

        txtVendaPesquisar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtVendaPesquisarKeyReleased(evt);
            }
        });
        jPanel3.add(txtVendaPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 31, 820, -1));

        tabVendas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "idvenda", "Categoria", "Item", "Vendedor", "Lucro"
            }
        ));
        jScrollPane1.setViewportView(tabVendas);

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(12, 84, 970, 120));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 460, 1000, 220));

        btnVendaAdicionar.setText("Adicionar venda");
        btnVendaAdicionar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendaAdicionarActionPerformed(evt);
            }
        });
        jPanel1.add(btnVendaAdicionar, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 400, 158, -1));

        btnVendaPesquisar.setText("Pesquisar");
        btnVendaPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendaPesquisarActionPerformed(evt);
            }
        });
        jPanel1.add(btnVendaPesquisar, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 400, 134, -1));

        btnVendaEditar.setText("Alterar venda");
        btnVendaEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendaEditarActionPerformed(evt);
            }
        });
        jPanel1.add(btnVendaEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 400, 134, -1));

        btnVendaRemover.setText("Remover venda");
        btnVendaRemover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendaRemoverActionPerformed(evt);
            }
        });
        jPanel1.add(btnVendaRemover, new org.netbeans.lib.awtextra.AbsoluteConstraints(780, 400, 144, -1));

        btnVendaLimpar.setText("Limpar campos");
        btnVendaLimpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVendaLimparActionPerformed(evt);
            }
        });
        jPanel1.add(btnVendaLimpar, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 400, 133, -1));

        jPanel4.setBackground(new java.awt.Color(255, 204, 204));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1379, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 786, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtVendaPesquisarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtVendaPesquisarKeyReleased
         pesquisarVenda();
    }//GEN-LAST:event_txtVendaPesquisarKeyReleased

    private void btnVendaLimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendaLimparActionPerformed
        limpar();
    }//GEN-LAST:event_btnVendaLimparActionPerformed

    private void btnVendaPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendaPesquisarActionPerformed
        pesquisarCompleto();
    }//GEN-LAST:event_btnVendaPesquisarActionPerformed

    private void btnVendaAdicionarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendaAdicionarActionPerformed
        adicionarVenda();
    }//GEN-LAST:event_btnVendaAdicionarActionPerformed

    private void btnVendaRemoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendaRemoverActionPerformed
        removerVenda();
    }//GEN-LAST:event_btnVendaRemoverActionPerformed

    private void btnVendaEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVendaEditarActionPerformed
        alterarVenda();
    }//GEN-LAST:event_btnVendaEditarActionPerformed

    private void txtIdCliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdCliActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdCliActionPerformed

    private void txtIdProdutoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdProdutoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdProdutoActionPerformed

    private void btnBuscaCpfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscaCpfActionPerformed
pesquisarCpfCliente();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnBuscaCpfActionPerformed

    private void txtProdutoPesquisarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtProdutoPesquisarKeyReleased
pesquisarProduto();

        // TODO add your handling code here:
    }//GEN-LAST:event_txtProdutoPesquisarKeyReleased

    private void txtQuantidadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtQuantidadeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtQuantidadeActionPerformed

    private void btnAdicionarProdutoNaVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAdicionarProdutoNaVendaActionPerformed
adicionarProduto();

        // TODO add your handling code here:
    }//GEN-LAST:event_btnAdicionarProdutoNaVendaActionPerformed

    
    
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TelaVendas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TelaVendas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TelaVendas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TelaVendas.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new TelaVendas().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAdicionarProdutoNaVenda;
    private javax.swing.JButton btnBuscaCpf;
    private javax.swing.JButton btnVendaAdicionar;
    private javax.swing.JButton btnVendaEditar;
    private javax.swing.JButton btnVendaLimpar;
    private javax.swing.JButton btnVendaPesquisar;
    private javax.swing.JButton btnVendaRemover;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tabVendas;
    private javax.swing.JTable tblProduto;
    private javax.swing.JTextField txtCpfCli;
    private javax.swing.JTextField txtIdCli;
    private javax.swing.JTextField txtIdProduto;
    private javax.swing.JTextField txtNomeCli;
    private javax.swing.JTextField txtProdutoPesquisar;
    private javax.swing.JTextField txtQuantidade;
    private javax.swing.JTextField txtValorTotal;
    private javax.swing.JTextField txtVenda;
    private javax.swing.JTextField txtVendaPesquisar;
    private javax.swing.JTextField txtVendedor;
    // End of variables declaration//GEN-END:variables
}
